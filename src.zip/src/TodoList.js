import React from 'react'
import Tasks from './Tasks'

export default function TodoList({ tasks, toggleTask }) {

    return (

        tasks.map(tasks => {

            return <Tasks key={tasks.id} toggleTask = {toggleTask} tasks = {tasks} />
        })

    )
}

/* function TodoList({ tasks }) renders out tasks

return ( tasks.map(task => { return <Tasks task = {task} /> })) prints out all of the tasks 

key = {tasks} only rerenders the things that actually change
 */