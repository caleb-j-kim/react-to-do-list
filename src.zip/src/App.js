import React, { useState, useRef, useEffect } from 'react';
import TodoList from './TodoList' //getting component from TodoList.js
import {v4 as uuidv4 } from 'uuid' //randomizes the id each time so there isn't a duplicate id
import ui from './ui'

const LOCAL_STORAGE_KEY = 'taskApp.tasks'

function App() {

  const [tasks, setTasks] = useState([]);
  const taskNameRef = useRef()

  useEffect(() => {

    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(tasks))
  }, [tasks])

  function toggleTask(id) {

    const newTasks = [...tasks]
    const task = newTasks.find(task => task.id === id) 
    task.complete = !TodoList.complete
    setTasks(newTasks)
  }

  function handleTasks(e) {

    const name = taskNameRef.current.value

    if (name === '') return
    console.log(name)
    setTasks(prevTasks => {
      return [...prevTasks, { id: 1, name: name, complete: false}]
    })
    taskNameRef.current.value = null
  }

function handleClearTasks() {

  const newTasks = tasks.filter(task => !task.complete)
  setTasks(newTasks)
}

  return (
  
    <>
    <TodoList tasks = {tasks} toggleTask={toggleTask}/>
    <input ref = {taskNameRef} type = "text" />
    <button onClick = {handleTasks}>Add Task</button>
    <button onClick = {handleClearTasks}>Clear Task</button>    
    <div>{tasks.filter(task => !task.complete).length} tasks left to do</div>
    
    </>
  )
}

export default App;

/* <> is a empty element
</>

<TodoList /> is the first element in the app component 
<input type = "text"/> creates a user input field

<button>name</button> creates a button and name is what the button is named
<div>msg</div> displays the msg on free space

{ useState } is a webhook that's imported from the react package

(object destructuring)
const [tasks, setTasks] = useState([]) 

creates a empty array useState and uses tasks (variable that represents all of the tasks)
and the function (setTasks) to update the tasks

<TodoList tasks = {tasks}/> is a example of a prop and passes the prop to the array list, etc

<button onClick = {handleTasks}> has the button call the function

useRef webhook allows us to reference elements inside of our HTML / user input 
<input ref = {taskNameRef} type = "text" /> creates a variable that uses the type box bottom on the website and stores it as a element

taskNameRef.current.value stores the latest user value to name in the task array
if (name === '') return returns a empty value to name if the text is empty

useEffect is another web hook 
first useEffect stores user into into name

  useEffect(() => { (supposed to make sure the tasks stay up when the page refreshes but when incorporated, makes whole screen blank)

    const storedTasks = JSON.stringify(localStorage.getItem(LOCAL_STORAGE_KEY))
    if (storedTasks) setTasks(storedTasks)
  }, [])

JSON.stringify parses into string array
>{tasks.filter(task => !task.complete).length} displays the total number of tasks that haven't been completed (doesn't have a check box)
*/