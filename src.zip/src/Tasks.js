import React from 'react'

export default function Tasks({ tasks, toggleTask }) {

function handleTaskClick() {

    toggleTask(tasks.id)
}

    return (

        <div>
            <label>
                <input type = "checkbox" checked = {tasks.complete} onChange = {handleTaskClick} />
        {tasks.name}
        </label>
        </div>
    )
}

/**
 * <label> </label> adds a label
 * <input type = "checkbox" checked = {tasks.complete} /> uses the complete variable to determine if something is completed or not 
 * (true makes the box turn into a checkbox, false makes the checkbox turn into a empty box)
 */